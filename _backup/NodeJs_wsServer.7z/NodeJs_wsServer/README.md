# NodeJs_onRender

## Hosting Node.js by Render
- Reference:
  - https://www.freecodecamp.org/chinese/news/how-to-deploy-nodejs-application-with-render/
  - https://medium.com/wei30172/heroku-%E7%9A%84%E6%9B%BF%E4%BB%A3%E6%96%B9%E6%A1%88-%E4%BD%BF%E7%94%A8-render-%E5%85%8D%E8%B2%BB%E4%BD%88%E7%BD%B2-node-js-app-bc0c2ac795ad
- Render: https://render.com/
- Result: https://renderhostingtest.onrender.com/

## Node.js
- MVC: https://hackmd.io/@Heidi-Liu/note-be201-express-node


==>
 NodeJs_onFirebase
 NodeJs_onRender


client (Chrome) --(request)--> server (Node.js)
protocal: HTTP


request:
1. url
2. xxxxxxx (header, cookie, session, method)
3. method:
   - GET
   - PUT
   - POST
   - DELETE

